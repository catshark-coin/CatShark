# 🦈 CatShark Coin (PURR)

**CatShark** is a fun, fast, and feisty meme token with real utility, born for the community.  
Backed by memes, driven by vibes, and secured on Solana. 💫

## 🌐 Links
- Telegram: [@CatSharkCoin](https://t.me/CatSharkCoin)
- Twitter (X): [@CatSharkCoin](https://x.com/CatSharkCoin)
- GitHub: [CatShark GitHub](https://github.com/catshark-coin)

## 📦 Tokenomics
- **Name:** CatShark Coin
- **Symbol:** PURR
- **Supply:** 1,000,000,000
- **Chain:** Solana (SPL Token)

## 📝 License
MIT License
